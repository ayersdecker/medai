import { Routes, Route, Link } from 'react-router-dom'
import RequireAuth from './auth/RequireAuth'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Pricing from './pages/Pricing'
import ProTool from './pages/ProTool'

export default function App() {
  return (
    <div style={{maxWidth: 860, margin: '40px auto', padding: 24}}>
      <nav style={{display:'flex', gap: 12, marginBottom: 24}}>
        <Link to="/">Home</Link>
        <Link to="/pricing">Pricing</Link>
        <Link to="/pro">Pro Tool</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/login" element={<Login />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/pro" element={<RequireAuth><ProTool /></RequireAuth>} />
      </Routes>
    </div>
  )
}